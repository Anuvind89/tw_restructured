'use strict';

app.controller('View1Ctrl', ['$scope', '$http', function($scope, $http, $window) {      //controller for view1
    $scope.tab = 1;
    $scope.welcomeMessage = true;                                   //display the welcome message in the empty div
    $scope.setTab = function(newTab){
      $scope.tab = newTab;                                          //tab enablement
      $scope.display = false;
    };

    $scope.isSet = function(tabNum){
      return $scope.tab === tabNum;
    };
    $scope.showReturn = function() {
      $scope.display = true;
    };
    $scope.slideValue=25000;
    var slider = document.getElementById("myRange");                //catch range slider input model
    slider.oninput = function() {
      $scope.slideValue=slider.value;
    }

    $scope.sendData = function() {                                  //invoke funtion on click of submit
      
      if ($scope.originCity && $scope.destinationCity && $scope.departureDate && ($scope.originCity != $scope.destinationCity)) {   //validations
        $scope.noAvailability = false;
        $scope.attachError = false;
        $scope.welcomeMessage = false;
      var userInputOriginCity = $scope.originCity;                  //extract user inputs
      var userInputDepartureCity = $scope.destinationCity;
      var userInputDepartureDate = $scope.departureDate;
      var userInputReturnDate = $scope.returnDate;
      var departYear = userInputDepartureDate.substring(0, 4);
      var departMonth = userInputDepartureDate.substring(5, 7);
      var departDate = userInputDepartureDate.substring(8,10);

      $http.get('flightData.json').success(function(response) {                           // HTTP get to obtain the flightData JSON
        var api_json = response;
          $scope.runningDepartureFlight = [];                                             //Business logic to extract departure flight based on user selection.
          angular.forEach(api_json, function(value, key) {                                //Compare if the flights are available for the user inputs for origin, destination, departure dates
            if (value.From == userInputOriginCity) {
              if (value.To == userInputDepartureCity) {
                if (value.Price<=$scope.slideValue) {
                  if (departYear == value.Time.Year) {
                    angular.forEach(value.Time.Month, function (months, key1){
                     if (months==departMonth) {
                        angular.forEach(value.Time.Date, function (dates, key2){
                          if (dates==departDate) {
                            $scope.runningDepartureFlight.push(value);
                          }
                        });
                        
                      }
                  });

                }
              }
              }
            }
          });
        $scope.hideReturn = true;
        if (userInputReturnDate) {                                                        //If the user has selected the return dates then this logic extractes the return flights from JSON object based on his selections
          var returnYear = userInputReturnDate.substring(0, 4);
          var returnMonth = userInputReturnDate.substring(5, 7);
          var returnDate = userInputReturnDate.substring(8,10);
          var tempAssignment = userInputOriginCity;
          userInputOriginCity = userInputDepartureCity;
          userInputDepartureCity = tempAssignment;
          $scope.runningReturnFlight = [];
          angular.forEach(api_json, function(value, key) {
            if (value.From == userInputOriginCity) {
              if (value.To == userInputDepartureCity) {
                if (returnYear == value.Time.Year) {
                  angular.forEach(value.Time.Month, function (months, key1){
                   if (months==returnMonth) {
                      angular.forEach(value.Time.Date, function (dates, key2){
                        if (dates==returnDate) {
                          $scope.runningReturnFlight.push(value);
                          $scope.hideReturn = false;
                        }
                      });
                      
                    }

                  });

                }
              }
            }
      });

      };

      if ($scope.runningDepartureFlight.length==0) {                                                //If there are no flights available, the non-availability message will be displayed
        $scope.noAvailability = true;
      }
    });
  }
else {
  $scope.attachError = true;
}
}}])